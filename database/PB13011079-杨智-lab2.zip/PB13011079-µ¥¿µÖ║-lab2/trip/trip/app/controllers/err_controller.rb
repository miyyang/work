class ErrController < ApplicationController
  def err
    
  end
end
